# Short note for the portal (edit it in your own words before submitting)

**What I built:** I cleaned a messy PDF-library dataset (318 rows, 10 columns) using Python and Pandas. I removed 18 duplicate rows, standardised spellings, fixed text and impossible values in number columns, converted mixed date formats, and checked the result with 7 automatic tests. I wrote a before/after data-quality report with 3 charts, and a README that explains how to run everything.

**What I learned:** (write 2-3 lines yourself, for example: how to look at missing values first, why a mapping table is better than fixing values one by one, why I did not invent values I could not know.)

**Files:** notebook `Week2_Data_Cleaning.ipynb`, `clean_data.py`, raw and clean CSV, `reports/DATA_QUALITY_REPORT.md`, 3 charts, README, demo video link.
