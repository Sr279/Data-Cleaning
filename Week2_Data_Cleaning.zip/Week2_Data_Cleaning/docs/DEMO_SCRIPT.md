# Demo video script (keep it under 5 minutes, show only the main flow)

Practise once before recording. Screen-record the notebook (or terminal) while you talk.

| Time | What to show | What to say (in your own words) |
|---|---|---|
| 0:00-0:30 | README / project folder | "This is my Week 2 project. I cleaned a messy PDF-library dataset and wrote a data-quality report." |
| 0:30-1:15 | Notebook Step 1 output (shape, head, missing values) | "First I looked at the data: 318 rows, 10 columns, and missing values in several columns." |
| 1:15-2:00 | Step 2 output (problem counts) | "I counted the problems before changing anything: duplicates, 15 spellings of 3 categories, text in number columns, impossible values, mixed dates." |
| 2:00-3:15 | Step 3 (scroll through 2-3 fixes, e.g. duplicates, category map, dates) | "I cleaned one problem at a time on a copy, so the raw file stays safe." |
| 3:15-3:45 | Step 4 "All 7 quality checks passed" | "Then I tested the cleaned data with automatic checks." |
| 3:45-4:30 | The 3 charts + `reports/DATA_QUALITY_REPORT.md` | "Each chart answers one question. The report shows before and after numbers and what is still unknown." |
| 4:30-5:00 | Close | "I learned ... (one real thing). Thank you." |

Tips: speak slowly, do not read the code line by line, and do not show errors you have not fixed.
