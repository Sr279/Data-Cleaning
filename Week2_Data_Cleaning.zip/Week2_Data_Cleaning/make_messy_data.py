"""Creates the messy practice dataset  data/raw/pdf_library_raw.csv
(seeded, so you always get the same file). It copies problems found in real data:
mixed spellings, text in number columns, impossible values, mixed date formats,
missing values and duplicate rows."""
import numpy as np
import pandas as pd
from pathlib import Path

rng = np.random.default_rng(42)
N = 300

topics = {"SQL Basics": "Database", "PostgreSQL Guide": "Database", "Database Design": "Database",
          "Python Guide": "Programming", "Pandas Notes": "Programming", "Testing with pytest": "Programming",
          "Power BI Intro": "Analytics", "Kaggle Report": "Analytics",
          "Data Cleaning Handbook": "Analytics", "Statistics Primer": "Analytics"}
names = list(topics)
titles = [f"{names[i % len(names)]} Vol {i // len(names) + 1}" for i in range(N)]
cats = [topics[names[i % len(names)]] for i in range(N)]
authors_pool = ["Asha Rao", "Ravi Kumar", "Meena Iyer", "Kiran Das",
                "Sita Devi", "Arjun Reddy", "Divya Nair", "Rahul Verma"]

df = pd.DataFrame({
    "doc_id": np.arange(1, N + 1),
    "title": titles,
    "author": rng.choice(authors_pool, N).astype(object),
    "category": np.array(cats, dtype=object),
    "page_count": rng.integers(5, 120, N).astype(object),
    "size_kb": rng.integers(100, 3000, N).astype(object),
    "created_date": pd.to_datetime("2022-01-01") + pd.to_timedelta(rng.integers(0, 1400, N), unit="D"),
    "language": rng.choice(["English", "Telugu", "Hindi"], N, p=[0.8, 0.12, 0.08]).astype(object),
    "downloads": rng.integers(0, 2000, N).astype(object),
    "reviewed": rng.choice(["Yes", "No"], N, p=[0.7, 0.3]).astype(object),
})

def pick(k):
    return rng.choice(N, size=k, replace=False)

# --- category: different spellings + missing
short = {"Database": "DB", "Programming": "Prog.", "Analytics": "Data Analytics"}
for i in pick(75):
    c = cats[i]
    df.at[i, "category"] = rng.choice([c.lower(), " " + c + " ", c.upper(), short[c]])
for i in pick(10):
    df.at[i, "category"] = None

# --- author: case/space problems, placeholders, missing
for i in pick(36):
    a = df.at[i, "author"]
    df.at[i, "author"] = rng.choice([a.lower(), a.upper(), a.replace(" ", "  ")])
for i in pick(10): df.at[i, "author"] = "Unknown"
for i in pick(6):  df.at[i, "author"] = "-"
for i in pick(5):  df.at[i, "author"] = "N/A"
for i in pick(8):  df.at[i, "author"] = None

# --- page_count: text, missing, impossible values
for i in pick(18): df.at[i, "page_count"] = f"{df.at[i, 'page_count']} pages"
for i in pick(12): df.at[i, "page_count"] = None
for i, v in zip(pick(4), [9999, -5, 0, 5000]): df.at[i, "page_count"] = v

# --- size_kb: text, missing, impossible values
for i in pick(18): df.at[i, "size_kb"] = f"{df.at[i, 'size_kb']} KB"
for i in pick(18): df.at[i, "size_kb"] = None
for i, v in zip(pick(5), [-1, -250, 0, 9999999, 8888888]): df.at[i, "size_kb"] = v

# --- downloads: missing, impossible values
for i in pick(24): df.at[i, "downloads"] = None
for i, v in zip(pick(5), [5000000, 7000000, -10, -3, 9000000]): df.at[i, "downloads"] = v

# --- created_date: mixed formats, invalid text, future dates, missing
dates = []
for d in df["created_date"]:
    r = rng.random()
    if r < 0.60:   dates.append(d.strftime("%Y-%m-%d"))
    elif r < 0.85: dates.append(d.strftime("%d/%m/%Y"))
    else:          dates.append(f"{d.strftime('%b')} {d.day}, {d.year}")
df["created_date"] = pd.Series(dates, dtype=object)
for i in pick(8):  df.at[i, "created_date"] = rng.choice(["not available", "TBD"])
for i in pick(6):  df.at[i, "created_date"] = "2031-05-20"
for i in pick(20): df.at[i, "created_date"] = None

# --- language and reviewed: different labels, missing
for i in pick(45):
    df.at[i, "language"] = {"English": "english", "Telugu": "te ", "Hindi": "HI"}[df.at[i, "language"]] \
        if df.at[i, "language"] != "English" else rng.choice(["english", "EN", "English "])
for i in pick(12): df.at[i, "language"] = None
for i in pick(120):
    df.at[i, "reviewed"] = {"Yes": rng.choice(["yes", "Y", "TRUE"]),
                            "No": rng.choice(["no", "N", "false"])}[df.at[i, "reviewed"]]
for i in pick(15): df.at[i, "reviewed"] = None

# --- duplicates: exact copies and copies with changed case / spaces
exact = df.iloc[pick(12)]
near = df.iloc[pick(6)].copy()
near["title"] = near["title"].str.upper() + " "
df = pd.concat([df, exact, near], ignore_index=True)
df = df.iloc[rng.permutation(len(df))].reset_index(drop=True)

Path("data/raw").mkdir(parents=True, exist_ok=True)
df.to_csv("data/raw/pdf_library_raw.csv", index=False)
print("Created data/raw/pdf_library_raw.csv with", len(df), "rows")
