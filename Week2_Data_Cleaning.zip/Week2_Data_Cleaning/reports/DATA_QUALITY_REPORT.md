# Data-Quality Report — PDF Library Dataset

## 1. Summary
| Measure | Before cleaning | After cleaning |
|---|---|---|
| Rows | 318 | 300 |
| Columns | 10 | 14 (3 extra `_imputed` flags and `created_year`) |
| Missing cells in the original 10 columns | 129 | 47 |
| Completeness of original 10 columns | 95.9% | 98.4% |
| Duplicate documents | 18 | 0 |

**In short:** 18 duplicate rows were removed, spellings were standardised, text and impossible values in number columns were fixed, mixed date formats were converted, and all 7 automatic quality checks pass.
Note: "completeness after" counts labels such as *Unknown* as filled, so section 6 lists what is still genuinely unknown.

## 2. Dataset
A PDF-library catalogue with one row per document: `doc_id`, `title`, `author`, `category`, `page_count`, `size_kb`, `created_date`, `language`, `downloads`, `reviewed`.
This is a practice dataset created by `make_messy_data.py` (seeded, so it is always identical). It copies problems common in real data. If your mentor requires a real dataset, repeat the same steps on it (see README).

## 3. How the data was checked
1. Looked at shape, first rows, data types and missing values.
2. Counted every problem (table in section 4) before changing anything.
3. Cleaned on a copy, one problem at a time, keeping the raw file untouched.
4. Ran 7 automatic checks (unique `doc_id`, no missing key columns, valid ranges, known categories, no future dates).

## 4. Problems found and what was done
| # | Issue | Column | Found in raw file | Action taken |
|---|---|---|---|---|
| 1 | Exact duplicate rows | all | 12 | Removed |
| 2 | Repeated doc_id (also case/space variants) | doc_id | 18 | Kept the first row for each doc_id |
| 3 | Different spellings of the same category | category | 15 labels | Mapped to 3 standard labels |
| 4 | Category missing or not recognised | category | 10 | Set to Uncategorised |
| 5 | Author missing or placeholder (Unknown, -) | author | 25 | Set to Unknown; names in Title Case |
| 6 | Number stored as text (e.g. 24 pages) | page_count | 17 | Extracted the number |
| 7 | Impossible values (0, negative, over 1000) | page_count | 4 | Set to missing, then median of category |
| 8 | Number stored as text (e.g. 820 KB) | size_kb | 17 | Extracted the number |
| 9 | Impossible values (0, negative, over 100000) | size_kb | 5 | Set to missing, then median of category |
| 10 | Impossible values (negative, over 1,000,000) | downloads | 5 | Set to missing, then overall median |
| 11 | Date could not be read (e.g. TBD) | created_date | 7 | Set to missing (not invented) |
| 12 | Date in the future | created_date | 5 | Set to missing (not invented) |
| 13 | Different spellings of language | language | 8 labels | Mapped to English / Telugu / Hindi / Unknown |
| 14 | Different spellings of yes/no | reviewed | 8 labels | Converted to True / False; missing stays missing |

## 5. Missing values per column
| Column | Before | After |
|---|---|---|
| doc_id | 0 | 0 |
| title | 0 | 0 |
| author | 13 | 0 |
| category | 11 | 0 |
| page_count | 12 | 0 |
| size_kb | 19 | 0 |
| created_date | 21 | 32 |
| language | 13 | 0 |
| downloads | 24 | 0 |
| reviewed | 16 | 15 |

`created_date` has **more** missing values after cleaning because 12 unreadable or future dates were blanked instead of being kept as wrong data. A smaller honest number of correct values is better than a full column with false dates.

Values filled with the median (flagged in the `_imputed` columns):

| # | Column | Values filled with median |
|---|---|---|
| 1 | page_count | 16 |
| 2 | size_kb | 23 |
| 3 | downloads | 28 |

## 6. Values that are still unknown (not invented)
| # | Column | Rows | How shown |
|---|---|---|---|
| 1 | author | 25 | Labelled Unknown |
| 2 | category | 10 | Labelled Uncategorised |
| 3 | language | 12 | Labelled Unknown |
| 4 | created_date | 32 | Left empty |
| 5 | reviewed | 15 | Left empty |

## 7. Decisions and assumptions
- `14/03/2025` is read as day/month/year.
- Median is used to fill numbers because extreme values do not affect it.
- Impossible values are treated as missing, not corrected by guessing.
- Reviewed status and dates are left empty when unknown, because guessing would add false information.
- 0 page counts are statistically high (IQR rule) but possible, so they were kept.

## 8. Charts
| Chart | Question it answers |
|---|---|
| ![Chart 1](../images/01_missing_values.png) | Which columns had missing values, and how many are left? |
| ![Chart 2](../images/02_page_count_outliers.png) | Were there impossible page counts? |
| ![Chart 3](../images/03_category_labels.png) | Are category labels consistent? |

## 9. Limitations and recommendations
- Median filling lowers natural variation; do not use `_imputed` rows for precise statistics.
- Use drop-down lists (fixed choices) for category, language and reviewed so spellings cannot differ.
- Add input rules: page_count 1–1000, size_kb above 0, dates not in the future.
- Add a unique-ID rule so the same document cannot be entered twice.
