# Week 2 — Data Cleaning: PDF Library Dataset + Data-Quality Report

**What it is:** A project that cleans a messy PDF-library dataset with Python and Pandas and explains the result in a data-quality report. It continues the PDF-library idea from Week 1.

**What I hand in (one sentence):** the cleaned dataset, a before/after data-quality report, the notebook, 3 charts and this README.

## Results
| | Before | After |
|---|---|---|
| Rows | 318 | 300 |
| Duplicate documents | 18 | 0 |
| Category spellings | 15 | 3 (+ Uncategorised) |
| Number columns with text or impossible values | yes | fixed |
| Automatic quality checks | - | 7 of 7 passed |

Full numbers and decisions: [`reports/DATA_QUALITY_REPORT.md`](reports/DATA_QUALITY_REPORT.md)

## Screenshots
![Missing values](images/01_missing_values.png)
![Page count outliers](images/02_page_count_outliers.png)
![Category labels](images/03_category_labels.png)

## Folder
```
Week2_Data_Cleaning/
  README.md
  requirements.txt
  Week2_Data_Cleaning.ipynb      <- main work (step by step, with explanations)
  clean_data.py                  <- same steps as one script
  make_messy_data.py             <- creates the raw practice dataset
  data/raw/pdf_library_raw.csv   <- messy data (never edited)
  data/clean/pdf_library_clean.csv
  reports/DATA_QUALITY_REPORT.md
  images/                        <- 3 charts
  docs/DEMO_SCRIPT.md            <- script for the 5-minute demo video
  docs/SUBMISSION_NOTE.md        <- short note for the portal
```

## How to run
**Option A - your computer**
1. `python -m venv .venv` and activate it (Windows: `.venv\Scripts\activate`, Mac/Linux: `source .venv/bin/activate`)
2. `pip install -r requirements.txt`
3. `jupyter notebook`, open `Week2_Data_Cleaning.ipynb`, then Run All.
   (or run everything at once: `python clean_data.py`)

**Option B - Google Colab (no install)**
1. Go to https://colab.research.google.com/ and upload the notebook.
2. In the left Files panel, upload `make_messy_data.py` (the notebook creates the raw data by itself) and then Runtime -> Run all.

## The dataset (please read)
`data/raw/pdf_library_raw.csv` is a **practice dataset created by `make_messy_data.py`**, not a download from a website. It copies the problems found in real data (duplicates, different spellings, text in number columns, impossible values, mixed date formats, missing values). Do not call it a "real-world dataset" in your submission.

## Using a real dataset instead (for example Titanic from Kaggle)
1. Download the CSV and save it as `data/raw/pdf_library_raw.csv`, or change `RAW_PATH` in Step 0.
2. Keep Steps 0-2 (look at data, count problems), Step 4 (tests) and Step 6 (report).
3. Rewrite Step 3 for your columns: names, mapping tables, valid ranges, date formats.
4. Change the column names in the charts and in the `issues` table of the report.

## Cleaning rules used
- Raw file is never edited; all work happens on a copy.
- Impossible values are marked missing, not guessed.
- Filled values are flagged in `*_imputed` columns.
- Unknown dates and unknown reviewed-status are left empty.

## Submission checklist
- [ ] Run the notebook top to bottom with no errors
- [ ] Open the report and check the numbers
- [ ] Add your own "What I learned" (notebook, last cell, and `docs/SUBMISSION_NOTE.md`)
- [ ] Record the demo video (under 5 minutes, see `docs/DEMO_SCRIPT.md`)
- [ ] Upload the zip / files in My Submissions before 05/11/2026 and check the status
