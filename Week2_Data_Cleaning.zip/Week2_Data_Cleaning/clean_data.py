"""Week 2 - Data cleaning pipeline. Run:  python clean_data.py
Reads data/raw/pdf_library_raw.csv, writes data/clean/pdf_library_clean.csv,
images/*.png and reports/DATA_QUALITY_REPORT.md (same steps as the notebook)."""
import matplotlib
matplotlib.use("Agg")

import re
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

RAW_PATH = Path("data/raw/pdf_library_raw.csv")
CLEAN_PATH = Path("data/clean/pdf_library_clean.csv")
REPORT_DATE = pd.Timestamp("2026-11-01")      # dates after this day are impossible
for folder in ["data/raw", "data/clean", "images", "reports"]:
    Path(folder).mkdir(parents=True, exist_ok=True)
if not RAW_PATH.exists():                      # create the practice file if it is missing
    exec(open("make_messy_data.py").read())
log = {}                                       # every problem we find is counted here

raw = pd.read_csv(RAW_PATH)
print("Shape (rows, columns):", raw.shape)
print()
print(raw.head(10))
print()
raw.info()
print()
print("Missing values per column:")
print(raw.isna().sum())

log["rows_raw"] = len(raw)
log["exact_duplicate_rows"] = int(raw.duplicated().sum())
log["duplicate_doc_ids"] = int(raw["doc_id"].duplicated().sum())
log["missing_cells_raw"] = int(raw.isna().sum().sum())
log["category_labels_raw"] = int(raw["category"].nunique())
log["language_labels_raw"] = int(raw["language"].nunique())
log["reviewed_labels_raw"] = int(raw["reviewed"].nunique())

def not_plain_number(series):
    """How many values are text such as '24 pages' instead of a plain number?"""
    s = series.dropna().astype(str)
    return int((~s.str.fullmatch(r"-?\d+(\.\d+)?")).sum())

log["page_count_text_values"] = not_plain_number(raw["page_count"])
log["size_kb_text_values"] = not_plain_number(raw["size_kb"])
missing_before = raw.isna().sum()

print("Exact duplicate rows      :", log["exact_duplicate_rows"])
print("Repeated doc_id values    :", log["duplicate_doc_ids"])
print("Category spellings found  :", log["category_labels_raw"], "(there should be 3)")
print("Language spellings found  :", log["language_labels_raw"], "(there should be 3)")
print("page_count stored as text :", log["page_count_text_values"])
print("size_kb stored as text    :", log["size_kb_text_values"])
print("Total missing cells       :", log["missing_cells_raw"])

df = raw.copy()
text_cols = ["title", "author", "category", "language", "reviewed"]
for col in text_cols:
    df[col] = df[col].astype("string").str.strip().str.replace(r"\s+", " ", regex=True)

df = df.drop_duplicates(subset="doc_id", keep="first").reset_index(drop=True)
log["duplicates_removed"] = log["rows_raw"] - len(df)
log["rows_clean"] = len(df)
print("Rows before:", log["rows_raw"], "| rows after:", len(df), "| removed:", log["duplicates_removed"])

CATEGORY_MAP = {"database": "Database", "db": "Database",
                "programming": "Programming", "prog.": "Programming", "prog": "Programming",
                "analytics": "Analytics", "data analytics": "Analytics"}
df["category"] = df["category"].str.lower().map(CATEGORY_MAP).fillna("Uncategorised")
log["category_unknown"] = int((df["category"] == "Uncategorised").sum())

LANG_MAP = {"english": "English", "en": "English", "eng": "English",
            "telugu": "Telugu", "te": "Telugu", "hindi": "Hindi", "hi": "Hindi"}
df["language"] = df["language"].str.lower().map(LANG_MAP).fillna("Unknown")
log["language_unknown"] = int((df["language"] == "Unknown").sum())

REVIEWED_MAP = {"yes": True, "y": True, "true": True, "no": False, "n": False, "false": False}
df["reviewed"] = df["reviewed"].str.lower().map(REVIEWED_MAP).astype("boolean")   # missing stays missing
log["reviewed_missing"] = int(df["reviewed"].isna().sum())
print(df["category"].value_counts())

author = df["author"].str.title()
author = author.mask(author.str.lower().isin(["unknown", "-", "?", "none"]))
log["author_missing_or_placeholder"] = int(author.isna().sum())
df["author"] = author.fillna("Unknown")
print(df["author"].value_counts())

def to_number(series):
    """'24 pages' -> 24, '820 KB' -> 820, text with no number -> NaN"""
    found = series.astype(str).str.extract(r"(-?\d+(?:\.\d+)?)")[0]
    return pd.to_numeric(found, errors="coerce")

# --- page_count: valid range 1 to 1000
df["page_count"] = to_number(df["page_count"])
bad = (df["page_count"] <= 0) | (df["page_count"] > 1000)
log["page_count_invalid"] = int(bad.sum())
df.loc[bad, "page_count"] = np.nan
df["page_count_imputed"] = df["page_count"].isna()
df["page_count"] = df["page_count"].fillna(df.groupby("category")["page_count"].transform("median"))
df["page_count"] = df["page_count"].fillna(df["page_count"].median()).round().astype("Int64")

# --- size_kb: valid range 1 to 100,000 KB
df["size_kb"] = to_number(df["size_kb"])
bad = (df["size_kb"] <= 0) | (df["size_kb"] > 100000)
log["size_kb_invalid"] = int(bad.sum())
df.loc[bad, "size_kb"] = np.nan
df["size_kb_imputed"] = df["size_kb"].isna()
df["size_kb"] = df["size_kb"].fillna(df.groupby("category")["size_kb"].transform("median"))
df["size_kb"] = df["size_kb"].fillna(df["size_kb"].median()).round().astype("Int64")

# --- downloads: valid range 0 to 1,000,000
df["downloads"] = to_number(df["downloads"])
bad = (df["downloads"] < 0) | (df["downloads"] > 1000000)
log["downloads_invalid"] = int(bad.sum())
df.loc[bad, "downloads"] = np.nan
df["downloads_imputed"] = df["downloads"].isna()
df["downloads"] = df["downloads"].fillna(df["downloads"].median()).round().astype("Int64")

for col in ["page_count", "size_kb", "downloads"]:
    log[col + "_imputed"] = int(df[col + "_imputed"].sum())
print({k: v for k, v in log.items() if "invalid" in k or "imputed" in k})

def parse_date(x):
    if pd.isna(x):
        return pd.NaT
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%b %d, %Y"):
        try:
            return pd.to_datetime(x, format=fmt)
        except (ValueError, TypeError):
            pass
    return pd.NaT

parsed = pd.Series([parse_date(x) for x in df["created_date"]], index=df.index)
parsed = pd.to_datetime(parsed)
log["date_unparseable"] = int((parsed.isna() & df["created_date"].notna()).sum())
log["date_in_future"] = int((parsed > REPORT_DATE).sum())
parsed = parsed.mask(parsed > REPORT_DATE)
log["date_missing_after"] = int(parsed.isna().sum())
df["created_date"] = parsed
df["created_year"] = df["created_date"].dt.year.astype("Int64")
print(df[["created_date", "created_year"]].head())

df["category"] = df["category"].astype("category")
df["language"] = df["language"].astype("category")
q1, q3 = df["page_count"].astype(float).quantile([0.25, 0.75])
upper_limit = q3 + 1.5 * (q3 - q1)
log["page_count_iqr_outliers"] = int((df["page_count"] > upper_limit).sum())
print("Data types after cleaning:")
print(df.dtypes)

assert df["doc_id"].is_unique, "duplicate doc_id found"
assert df[["title", "author", "category", "page_count", "size_kb", "downloads"]].notna().all().all(), "missing values left"
assert df["page_count"].between(1, 1000).all(), "page_count out of range"
assert (df["size_kb"] > 0).all(), "size_kb must be positive"
assert df["downloads"].between(0, 1000000).all(), "downloads out of range"
assert set(df["category"].astype(str)) <= {"Database", "Programming", "Analytics", "Uncategorised"}, "unknown category"
assert (df["created_date"].dropna() <= REPORT_DATE).all(), "future date left"
print("All 7 quality checks passed")

# Chart 1 — Question: which columns had missing values, and how many are left?
raw_cols = list(raw.columns)
compare = pd.DataFrame({"before cleaning": missing_before, "after cleaning": df[raw_cols].isna().sum()})
ax = compare.plot(kind="bar", figsize=(9, 4), color=["#d9534f", "#5cb85c"])
ax.set_title("Chart 1: Which columns had missing values?")
ax.set_ylabel("Number of missing values")
plt.xticks(rotation=45, ha="right")
plt.tight_layout()
plt.savefig("images/01_missing_values.png", dpi=120)
plt.close()

# Chart 2 — Question: were there impossible page counts?
fig, axes = plt.subplots(1, 2, figsize=(9, 4))
axes[0].boxplot(to_number(raw["page_count"]).dropna())
axes[0].set_title("Before cleaning")
axes[1].boxplot(df["page_count"].astype(float))
axes[1].set_title("After cleaning")
for a in axes:
    a.set_ylabel("Pages")
fig.suptitle("Chart 2: Were there impossible page counts?")
plt.tight_layout()
plt.savefig("images/02_page_count_outliers.png", dpi=120)
plt.close()

# Chart 3 — Question: are category labels consistent?
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
raw["category"].fillna("(missing)").value_counts().plot(kind="barh", ax=axes[0], color="#d9534f")
axes[0].set_title("Before: %d different labels" % log["category_labels_raw"])
df["category"].astype(str).value_counts().plot(kind="barh", ax=axes[1], color="#5cb85c")
axes[1].set_title("After: %d clean labels" % df["category"].nunique())
fig.suptitle("Chart 3: Are category labels consistent?")
plt.tight_layout()
plt.savefig("images/03_category_labels.png", dpi=120)
plt.close()

df.to_csv(CLEAN_PATH, index=False)
print("Saved", CLEAN_PATH, "with", df.shape[0], "rows and", df.shape[1], "columns")

def md_table(frame, index_name=""):
    header = [index_name] + [str(c) for c in frame.columns]
    lines = ["| " + " | ".join(header) + " |", "|" + "---|" * len(header)]
    for idx, row in frame.iterrows():
        lines.append("| " + " | ".join([str(idx)] + [str(v) for v in row]) + " |")
    return "\n".join(lines)

n_cols = raw.shape[1]
complete_before = 100 * (1 - log["missing_cells_raw"] / (log["rows_raw"] * n_cols))
missing_after = df[raw_cols].isna().sum()
complete_after = 100 * (1 - missing_after.sum() / (len(df) * n_cols))

issues = pd.DataFrame([
    ["Exact duplicate rows", "all", log["exact_duplicate_rows"], "Removed"],
    ["Repeated doc_id (also case/space variants)", "doc_id", log["duplicate_doc_ids"], "Kept the first row for each doc_id"],
    ["Different spellings of the same category", "category", str(log["category_labels_raw"]) + " labels", "Mapped to 3 standard labels"],
    ["Category missing or not recognised", "category", log["category_unknown"], "Set to Uncategorised"],
    ["Author missing or placeholder (Unknown, -)", "author", log["author_missing_or_placeholder"], "Set to Unknown; names in Title Case"],
    ["Number stored as text (e.g. 24 pages)", "page_count", log["page_count_text_values"], "Extracted the number"],
    ["Impossible values (0, negative, over 1000)", "page_count", log["page_count_invalid"], "Set to missing, then median of category"],
    ["Number stored as text (e.g. 820 KB)", "size_kb", log["size_kb_text_values"], "Extracted the number"],
    ["Impossible values (0, negative, over 100000)", "size_kb", log["size_kb_invalid"], "Set to missing, then median of category"],
    ["Impossible values (negative, over 1,000,000)", "downloads", log["downloads_invalid"], "Set to missing, then overall median"],
    ["Date could not be read (e.g. TBD)", "created_date", log["date_unparseable"], "Set to missing (not invented)"],
    ["Date in the future", "created_date", log["date_in_future"], "Set to missing (not invented)"],
    ["Different spellings of language", "language", str(log["language_labels_raw"]) + " labels", "Mapped to English / Telugu / Hindi / Unknown"],
    ["Different spellings of yes/no", "reviewed", str(log["reviewed_labels_raw"]) + " labels", "Converted to True / False; missing stays missing"],
], columns=["Issue", "Column", "Found in raw file", "Action taken"]).set_index(pd.RangeIndex(1, 15))

missing_table = pd.DataFrame({"Before": missing_before, "After": missing_after})
still_unknown = pd.DataFrame([
    ["author", int((df["author"] == "Unknown").sum()), "Labelled Unknown"],
    ["category", log["category_unknown"], "Labelled Uncategorised"],
    ["language", log["language_unknown"], "Labelled Unknown"],
    ["created_date", log["date_missing_after"], "Left empty"],
    ["reviewed", log["reviewed_missing"], "Left empty"],
], columns=["Column", "Rows", "How shown"]).set_index(pd.RangeIndex(1, 6))
imputed = pd.DataFrame([
    ["page_count", log["page_count_imputed"]], ["size_kb", log["size_kb_imputed"]],
    ["downloads", log["downloads_imputed"]]], columns=["Column", "Values filled with median"]).set_index(pd.RangeIndex(1, 4))

report = f"""# Data-Quality Report — PDF Library Dataset

## 1. Summary
| Measure | Before cleaning | After cleaning |
|---|---|---|
| Rows | {log["rows_raw"]} | {log["rows_clean"]} |
| Columns | {n_cols} | {df.shape[1]} (3 extra `_imputed` flags and `created_year`) |
| Missing cells in the original 10 columns | {log["missing_cells_raw"]} | {int(missing_after.sum())} |
| Completeness of original 10 columns | {complete_before:.1f}% | {complete_after:.1f}% |
| Duplicate documents | {log["duplicate_doc_ids"]} | 0 |

**In short:** {log["duplicates_removed"]} duplicate rows were removed, spellings were standardised, text and impossible values in number columns were fixed, mixed date formats were converted, and all 7 automatic quality checks pass.
Note: "completeness after" counts labels such as *Unknown* as filled, so section 6 lists what is still genuinely unknown.

## 2. Dataset
A PDF-library catalogue with one row per document: `doc_id`, `title`, `author`, `category`, `page_count`, `size_kb`, `created_date`, `language`, `downloads`, `reviewed`.
This is a practice dataset created by `make_messy_data.py` (seeded, so it is always identical). It copies problems common in real data. If your mentor requires a real dataset, repeat the same steps on it (see README).

## 3. How the data was checked
1. Looked at shape, first rows, data types and missing values.
2. Counted every problem (table in section 4) before changing anything.
3. Cleaned on a copy, one problem at a time, keeping the raw file untouched.
4. Ran 7 automatic checks (unique `doc_id`, no missing key columns, valid ranges, known categories, no future dates).

## 4. Problems found and what was done
{md_table(issues, "#")}

## 5. Missing values per column
{md_table(missing_table, "Column")}

`created_date` has **more** missing values after cleaning because {log["date_unparseable"] + log["date_in_future"]} unreadable or future dates were blanked instead of being kept as wrong data. A smaller honest number of correct values is better than a full column with false dates.

Values filled with the median (flagged in the `_imputed` columns):

{md_table(imputed, "#")}

## 6. Values that are still unknown (not invented)
{md_table(still_unknown, "#")}

## 7. Decisions and assumptions
- `14/03/2025` is read as day/month/year.
- Median is used to fill numbers because extreme values do not affect it.
- Impossible values are treated as missing, not corrected by guessing.
- Reviewed status and dates are left empty when unknown, because guessing would add false information.
- {log["page_count_iqr_outliers"]} page counts are statistically high (IQR rule) but possible, so they were kept.

## 8. Charts
| Chart | Question it answers |
|---|---|
| ![Chart 1](../images/01_missing_values.png) | Which columns had missing values, and how many are left? |
| ![Chart 2](../images/02_page_count_outliers.png) | Were there impossible page counts? |
| ![Chart 3](../images/03_category_labels.png) | Are category labels consistent? |

## 9. Limitations and recommendations
- Median filling lowers natural variation; do not use `_imputed` rows for precise statistics.
- Use drop-down lists (fixed choices) for category, language and reviewed so spellings cannot differ.
- Add input rules: page_count 1–1000, size_kb above 0, dates not in the future.
- Add a unique-ID rule so the same document cannot be entered twice.
"""
Path("reports/DATA_QUALITY_REPORT.md").write_text(report, encoding="utf-8")
print("Report saved to reports/DATA_QUALITY_REPORT.md")
